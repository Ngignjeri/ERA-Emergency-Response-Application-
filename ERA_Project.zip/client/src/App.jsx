import { useEffect, useState } from "react";
import axios from "axios";
import io from "socket.io-client";
import MapView from "./MapView";

const socket = io("http://localhost:5000");

export default function App() {
  const [location, setLocation] = useState(null);
  const [emergency, setEmergency] = useState(null);
  const [status, setStatus] = useState("Ready");

  useEffect(() => {
    navigator.geolocation.getCurrentPosition((pos) => {
      setLocation({
        lat: pos.coords.latitude,
        lng: pos.coords.longitude
      });
    });
  }, []);

  useEffect(() => {
    socket.on("emergency-accepted", (data) => {
      setEmergency(data);
      setStatus("🚑 Help is coming!");
    });

    socket.on("location-update", (data) => {
      setEmergency(data);
    });
  }, []);

  const sendEmergency = async () => {
    const res = await axios.post("http://localhost:5000/emergency", {
      userId: "123",
      location
    });

    setEmergency(res.data);
    setStatus("Waiting for responder...");
  };

  return (
    <div style={{ textAlign: "center" }}>
      <h1>🚨 ERA</h1>

      <button onClick={sendEmergency}>
        CALL EMERGENCY
      </button>

      <p>{status}</p>

      {location && (
        <MapView
          userLocation={location}
          responderLocation={emergency?.responderLocation}
        />
      )}
    </div>
  );
}
