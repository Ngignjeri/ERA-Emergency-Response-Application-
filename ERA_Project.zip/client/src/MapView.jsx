import { MapContainer, TileLayer, Marker } from "react-leaflet";

export default function MapView({ userLocation, responderLocation }) {
  return (
    <MapContainer center={userLocation} zoom={13} style={{ height: "400px" }}>
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      <Marker position={userLocation} />
      {responderLocation && <Marker position={responderLocation} />}
    </MapContainer>
  );
}
