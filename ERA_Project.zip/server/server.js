const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/era");

const User = mongoose.model("User", {
  name: String,
  medicalHistory: String,
});

const Emergency = mongoose.model("Emergency", {
  userId: String,
  status: String,
  userLocation: Object,
  responderLocation: Object
});

app.post("/user", async (req, res) => {
  const user = await User.create(req.body);
  res.json(user);
});

app.post("/emergency", async (req, res) => {
  const emergency = await Emergency.create({
    userId: req.body.userId,
    status: "pending",
    userLocation: req.body.location
  });

  io.emit("new-emergency", emergency);
  res.json(emergency);
});

app.post("/accept/:id", async (req, res) => {
  const emergency = await Emergency.findByIdAndUpdate(
    req.params.id,
    {
      status: "accepted",
      responderLocation: req.body.responderLocation
    },
    { new: true }
  );

  io.emit("emergency-accepted", emergency);
  res.json(emergency);
});

app.post("/update-location/:id", async (req, res) => {
  const emergency = await Emergency.findByIdAndUpdate(
    req.params.id,
    { responderLocation: req.body.responderLocation },
    { new: true }
  );

  io.emit("location-update", emergency);
  res.json(emergency);
});

server.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});
